import os
from flask import Flask, render_template, request, flash, redirect, url_for, g, current_app , abort
from flask_login import LoginManager, current_user, login_user, logout_user, login_required, UserMixin


from flask_bootstrap import Bootstrap
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate


from flask_wtf import FlaskForm
from wtforms import StringField,IntegerField, FloatField, PasswordField, SubmitField, SelectMultipleField, TimeField, FileField
from wtforms.validators import DataRequired, Email, EqualTo, ValidationError
from flask_wtf.file import FileField, FileRequired, FileAllowed

from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.urls import url_parse
from werkzeug.utils import secure_filename

#import bcrypt

import os
#import secrets
#from PIL import Image

import datetime
from datetime import datetime
import pytz
from pytz import timezone



app = Flask(__name__)
app.config['SECRET_KEY'] = 'MY_SECRET_KEY'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///ticketshow.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['POSTS_PER_PAGE'] = 4
#app.config['UPLOAD_FOLDER'] = 'static/shows'
#app.config['ALLOWED_IMAGE_EXTENSIONS'] = ['JPG', 'PNG']
app.config['MAX_CONTENT_LENGTH'] = 8 * 1024 * 1024

Bootstrap(app)
db = SQLAlchemy(app)

migrate = Migrate(app, db, render_as_batch=True)



login = LoginManager(app)
login.login_view = 'login'
login.init_app(app)



class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    #role = db.Column(db.String(20), nullable=False, default='user')
    ticketbook = db.relationship('Booking', backref='user', lazy='subquery')
    
    @property
    def password(self):
        raise AttributeError('password is not a readable attribute')
    
    @password.setter
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

@login.user_loader
def load_user(user_id):
    # return the user object for the user with the given user_id
    if User.query.get(int(user_id)):
        return User.query.get(int(user_id))
    elif Admin.query.get(int(user_id)):
        return Admin.query.get(int(user_id))



class Admin(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    #role = db.Column(db.String(20), nullable=False, default='admin')

    @property
    def password(self):
        raise AttributeError('password is not a readable attribute')
    
    @password.setter
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Venue(db.Model):
    
    id = db.Column(db.Integer, primary_key=True)
    venuename = db.Column(db.String(100), nullable=False)
    location = db.Column(db.String(100), nullable=False)
    capacity = db.Column(db.Integer, nullable=False)
    
    last_updated = db.Column(db.DateTime, default=datetime.now(timezone('Asia/Kolkata')), onupdate=datetime.now(timezone('Asia/Kolkata')))
    shows = db.relationship('Show', secondary='show_venue', backref=db.backref('venues', lazy='dynamic'))
    projected = db.relationship('Showing', backref='venue', lazy=True)

    def __repr__(self):
        return f"Show('{self.id}', '{self.venuename}', '{self.last_updated}')"



class Show(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    showname = db.Column(db.String(100), nullable=False)

    time= db.Column(db.String(100), nullable=False)
    rating = db.Column(db.Float, db.ForeignKey('venue.id'), nullable=False)
    price = db.Column(db.Integer, db.ForeignKey('venue.id'), nullable=False)
    tag = db.Column(db.String(100), nullable=False)
    last_updated = db.Column(db.DateTime, default=datetime.now(timezone('Asia/Kolkata')), onupdate=datetime.now(timezone('Asia/Kolkata')))

    projected = db.relationship('Showing', backref='show', lazy=True)

    def __repr__(self):
        return f"Show('{self.id}', '{self.showname}', '{self.last_updated}')"



class Showing(db.Model):

    id = db.Column(db.Integer, primary_key=True)
    show_id = db.Column(db.Integer, db.ForeignKey('show.id'))
    venue_id = db.Column(db.Integer, db.ForeignKey('venue.id'))
    available = db.Column(db.Integer, nullable=False)
    show_booked = db.relationship('Booking', backref='showing', lazy=True, overlaps='show_booked,showing')
 
show_venue = db.Table('show_venue',db.Column('show_id', db.Integer, db.ForeignKey('show.id')),db.Column('venue_id', db.Integer, db.ForeignKey('venue.id')))


class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    showing_id = db.Column(db.Integer, db.ForeignKey('showing.id'), nullable=False)
    num_seats = db.Column(db.Integer, unique=False, nullable=False)
    last_updated = db.Column(db.DateTime, default=datetime.now(timezone('Asia/Kolkata')), onupdate=datetime.now(timezone('Asia/Kolkata')))
    showtime = db.relationship('Showing', backref=db.backref('Booking', lazy=True), overlaps='show_booked,showing')
    def __repr__(self):
        return f"Booking('{self.id}', '{self.last_updated}')"









class VenueForm(FlaskForm):
    venuename = StringField('Venue name', validators=[DataRequired()])
    location = StringField('location', validators=[DataRequired()])
    capacity = IntegerField('capacity', validators=[DataRequired()])

    submit = SubmitField('Venue')

class ShowForm(FlaskForm):
    showname = StringField('showname', validators=[DataRequired()])
    #poster = FileField('Poster', validators=[FileAllowed(['jpg', 'png'])])
    time = TimeField('Time', validators=[DataRequired()])

    rating = FloatField('rating', validators=[DataRequired()])

    #Tag=StringField('tag', validators=[DataRequired()])

    price = IntegerField('price', validators=[DataRequired()])
    tag = StringField('tag', validators=[DataRequired()])

    venues = SelectMultipleField('Venue', coerce=int )


#list of v where show run
    #Venue = StringField('Venue name', validators=[DataRequired()])
    submit = SubmitField('Show')


class BookingForm(FlaskForm):

    num_seats=IntegerField('num_seats ',validators=[DataRequired()])
    submitt=SubmitField('book_ticket')

    
#create end

#edit

    # 
class UpdateVenueForm(FlaskForm):
    venuename = StringField('venuename', validators=[DataRequired()])
    location = StringField('location', validators=[DataRequired()])
    capacity = IntegerField('show', validators=[DataRequired()])
    
    #shows = StringField('show', validators=[DataRequired()])

    submit = SubmitField('Submit')


class UpdateShowForm(FlaskForm):
    showname = StringField('Show name', validators=[DataRequired()])
    time = TimeField('Time', validators=[DataRequired()])
    
    rating = FloatField('show', validators=[DataRequired()])
    
    price = IntegerField('show', validators=[DataRequired()])
    tag = StringField('tag', validators=[DataRequired()])

#list of v where show run
    #Venue = StringField('Venue name', validators=[DataRequired()])
    submit = SubmitField('Submit')


##

#delete
class DeleteVenueForm(FlaskForm):
    submit = SubmitField('Delete')

class DeleteShowForm(FlaskForm):
    submit = SubmitField('Delete')


#fucn check capacity
#fucn book
class SearchLocationVenueForm(FlaskForm):
    q = StringField('Search', validators=[DataRequired()], default="")

class SearchRatingShowForm(FlaskForm):
    q = StringField('Search', validators=[DataRequired()], default="")

class SearchTagShowForm(FlaskForm):
    q = StringField('Search', validators=[DataRequired()], default="")



###############

class UpdateAccountForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    profile_image = FileField('Profile Image', validators=[FileAllowed(['jpg', 'png'])])
    submit = SubmitField('Update')

    def validate_username(self, username):
        if username.data != current_user.username:
            user = User.query.filter_by(username=username.data).first()
            if user is not None:
                raise ValidationError('Username is already taken. Please choose another one !!')


class DeleteAccountForm(FlaskForm):
    password = PasswordField('Password', validators=[DataRequired()])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Delete Account')


################

class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Sign Up')

    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user:
            raise ValidationError('Username is already taken. Please choose another one !!')


class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Log In')

class AdminLoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Log In')





@app.route("/showings/<int:showing_id>/book/", methods=['GET', 'POST'])
@login_required
def book(showing_id):
    user_id=current_user.id
    showing = Showing.query.get_or_404(showing_id)
    form = BookingForm()
    showname= showing.show.showname 
    venuename=showing.venue.venuename 

    if form.validate_on_submit():
        # Check if the requested number of tickets are available
        if showing.available==0:
            flash('HOUSEFULL!!', 'danger')
            return redirect(url_for('showings'))

        elif showing.available < form.num_seats.data:
            

            flash('Sorry, only {} tickets are available for this show.'.format(showing.available()), 'danger')
            return redirect(url_for('book', showing_id=showing_id))
        else:
            showing.available = showing.available - form.num_seats.data
            db.session.commit()

        # Create tickets and add to the database
        
        ticket = Booking(showing_id=showing.id,user_id=user_id,num_seats=form.num_seats.data)
        db.session.add(ticket)

        db.session.commit()
        flash('Successfully booked {} tickets!'.format(form.num_seats.data), 'success')
        return redirect(url_for('showings'))

    return render_template('book.html', showing=showing, form=form,showname=showname,venuename=venuename)

#rotes
# WELCOME page
@app.route('/')
def welcome():
    return render_template('welcome.html')

@app.route('/admindashboard', methods=['GET', 'POST'])
def admindashboard():
    return render_template('admindashboard.html')


# REGISTRATION page
@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('showings'))

    form = RegistrationForm()

    if form.validate_on_submit():
        # check if the username is already registered or the username is already taken
        user = User.query.filter_by(username=form.username.data).first()
        if user is not None:
            flash('User already registered !!')
            return redirect(url_for('login'))

        # Create a new user object and set their password
        hashed_password = generate_password_hash(form.password.data)
        new_user = User(username=form.username.data, password_hash=hashed_password)

        # Add the user object to the database and commit the changes
        db.session.add(new_user)
        db.session.commit()
        
        flash('Successfully Registered !!')
        return redirect(url_for('login'))
    return render_template('register.html', form=form)



# LOGIN page
@app.route("/login", methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('showings'))

    form = LoginForm()

    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        
        # user.is_active = True
        if user and user.check_password(form.password.data) :
            login_user(user)
            flash('Successfully logged in !!', 'success')

            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('showings'))
        else:
            flash('Login Unsuccessful !!', 'danger')
            flash('Invalid username or password !!')
    return render_template('login.html', title='Login', form=form)


@app.route("/adminlogin", methods=['GET', 'POST'])
def adminlogin():
    if current_user.is_authenticated and current_user.username == 'admin':
        return redirect(url_for('admindashboard'))

    form = AdminLoginForm()

    if form.validate_on_submit():
        user = Admin.query.filter_by(username=form.username.data).first()
        
        # user.is_active = True
        if user and user.check_password(form.password.data):
            login_user(user)
            flash('Successfully logged in !!', 'success')

            return redirect(url_for('admindashboard'))
        else:
            flash('Login Unsuccessful !!', 'danger')
            flash('Invalid username or password !!')
    return render_template('adminlogin.html', title='Admin Login', form=form)



# LOGOUT page
@app.route("/logout")
@login_required
def logout():
    logout_user()
    flash('Logged out Successfully !!' , 'success')
    return redirect(url_for('welcome'))







# --------------------------------------------------------------------------------
@app.route("/admindashboard/show/", methods=['GET', 'POST'])
@login_required
def show():
    if current_user.username != 'admin':
        abort(403)
    shows = Show.query.order_by(Show.last_updated.desc()).all()

    #form = CommentForm()
    return render_template('show.html', title='Show page',shows=shows)

@app.route("/admindashboard/venue/", methods=['GET', 'POST'])
@login_required
def venue():
    if current_user.username != 'admin':
        abort(403)

    venues = Venue.query.order_by(Venue.last_updated.desc()).all()

    return render_template('venue.html', title='venue page', venues=venues)



#create show
@app.route("/admindashboard/show/create_show", methods=['GET', 'POST'])
@login_required
def create_show():
    if current_user.username != 'admin':
        abort(403)
    form = ShowForm()
    
    if request.method == 'POST' or form.validate_on_submit():
        
        time_str = form.time.data.strftime("%H:%M")    
        show = Show(showname=form.showname.data, time=time_str, rating=form.rating.data,  price=form.price.data , tag=form.tag.data)
        db.session.add(show)
        db.session.commit()

        selected_venues = request.form.getlist('venues')
        venues = Venue.query.order_by(Venue.id.desc()).all()
        #showing =Showing(venue_id=)
        show = Show.query.order_by(Show.last_updated.desc()).first()
        for venue_id in selected_venues:
            venue = Venue.query.filter_by(id = venue_id).first()
            showing = Showing(show_id=show.id, venue_id=venue_id, available=venue.capacity)
            db.session.add(showing)
        
        db.session.commit()

        flash('Show created !!', 'success')
        return redirect(url_for('admindashboard', username=current_user.username))
        # Get the list of all venues
    venues = Venue.query.all()
    
    # Create a list of choices for the venue selection field
    choices = [(v.id, v.venuename) for v in venues]
    return render_template('create_show.html', title='Create Show page', form=form, choices=choices)



# UPDATE_SHOW page
@app.route("/admindashboard/show/<int:show_id>/update_show", methods=['GET', 'POST'])
@login_required
def update_show(show_id):
    show = Show.query.get_or_404(show_id)
    if current_user.username != 'admin':
        abort(403)
    form = UpdateShowForm()

    if form.validate_on_submit():
        time_str = form.time.data.strftime("%H:%M")   

        show.showname=form.showname.data
        show.time = time_str
        show.rating=form.rating.data  
        show.price=form.price.data 
        show.tag=form.tag.data

        selected_venues = request.form.getlist('venues')
        for venue_id in selected_venues:
            try:
                venue = Venue.query.filter_by(id = venue_id).first()
                showing = Showing(show_id=show_id, venue_id=venue_id, available=venue.capacity)
                db.session.add(showing)
            except:
                pass
            db.session.commit()

        flash('Show updated !!', 'success')
        return redirect(url_for('admindashboard', username=current_user.username))
    venues = Venue.query.all()
    choices = [(v.id, v.venuename) for v in venues]
    return render_template('update_show.html', title='updateShow page', form=form,show_id=show.id,choices=choices)

@app.route("/admindashboard/show/<int:show_id>/delete_show", methods=['GET','POST'])
@login_required
def delete_show(show_id):
    show = Show.query.get_or_404(show_id)
    if current_user.username != 'admin':
        abort(403)

    form = DeleteShowForm()

    if form.validate_on_submit():


        db.session.query(Showing).filter_by(show_id=show_id).delete()

        db.session.delete(show)
        db.session.commit()

        flash('Show Deleted !!', 'success')
        return redirect(url_for('admindashboard', username=current_user.username))

    return render_template('delete_show.html', show=show, form=form)


# CREATE_VENUE page
@app.route("/admindashboard/venue/create_venue", methods=['GET', 'POST'])
@login_required
def create_venue():
    if current_user.username != 'admin':
        abort(403)

    form = VenueForm()

    if form.validate_on_submit():
        
        venue = Venue(venuename=form.venuename.data, location=form.location.data,  capacity=form.capacity.data )
        db.session.add(venue)
        db.session.commit()

        flash('Venue created !!', 'success')
        return redirect(url_for('admindashboard', username=current_user.username))

    return render_template('create_venue.html', title='Create venue page', form=form)

# UPDATE_venue page
@app.route("/admindashboard/venue/<int:venue_id>/update_venue", methods=['GET', 'POST'])
@login_required
def update_venue(venue_id):
    venue = Venue.query.get_or_404(venue_id)
    if current_user.username != 'admin':
        abort(403)
    form = UpdateVenueForm()

    if form.validate_on_submit():
        venue.venuename=form.venuename.data
        venue.location=form.location.data  
        venue.capacity=form.capacity.data 

        db.session.commit()

        flash('Venue updated !!', 'success')
        return redirect(url_for('admindashboard', username=current_user.username))

    return render_template('update_venue.html', title='update venue page', form=form,venue_id=venue.id)

@app.route("/admindashboard/venue/<int:venue_id>/delete_venue", methods=['GET','POST'])
@login_required
def delete_venue(venue_id):
    venue = Venue.query.get_or_404(venue_id)
    if current_user.username != 'admin':
        abort(403)

    form = DeleteVenueForm()

    if form.validate_on_submit():


        # delete the tags associated with the post 
        db.session.query(Showing).filter_by(venue_id=venue_id).delete()

        db.session.delete(venue)
        db.session.commit()

        flash('Venue Deleted !!', 'success')
        return redirect(url_for('admindashboard', username=current_user.username))

    return render_template('delete_venue.html', venue=venue, form=form)



@app.route('/showings')
def showings():
    #showing_list = Showing.query.all()
    showing_list = Showing.query.join(Show, Showing.show_id == Show.id)\
                       .join(Venue, Showing.venue_id == Venue.id)\
                       .all()
    #.join(Show).join(Venue)
    return render_template('showings.html', showing_list=showing_list)



# PROFILE page
@app.route("/profile/<username>")
@login_required
def profile(username):
    if username !='admin':
        user = User.query.filter_by(username=username).first_or_404()
        booking_list = Booking.query.join(Showing, Booking.showing_id == Showing.id)\
                        .join(Venue, Showing.venue_id == Venue.id)\
                        .join(Show, Showing.show_id == Show.id)\
                        .order_by(Booking.last_updated.desc()).all()
        
        return render_template('profile.html',user=user, booking_list=booking_list)
    


# SEARCH page (statements for debugging)
@app.route("/searchlocationvenue", methods=['GET', 'POST'])
@login_required
def searchlocationvenue():
    form = SearchLocationVenueForm()
    if form.validate_on_submit():
        query = form.q.data
        print(f"Search query: {query}")

        if query: 

            venues = Venue.query.filter(Venue.location.like(f"%{query}%")).all()
            print(f"Search results: {venues}")
        else:
            venues = []

        return render_template('searchlocationvenue.html',form=form, venues=venues, query=query, default_value="")

    return render_template('searchlocationvenue.html', form=form, default="")

@app.route("/searchtagshow", methods=['GET', 'POST'])
@login_required
def searchtagshow():
    form = SearchTagShowForm()
    if form.validate_on_submit():
        query = form.q.data
        print(f"Search query: {query}")

        if query: 

            shows = Show.query.filter(Show.tag.like(f"%{query}%")).all()
            print(f"Search results: {shows}")
        else:
            shows = []

        return render_template('searchtagshow.html')

    return render_template('searchtagshow.html')

@app.route("/searchratingshow", methods=['GET', 'POST'])
@login_required
def search():
    form = SearchRatingShowForm()
    if form.validate_on_submit():
        query = form.q.data
        print(f"Search query: {query}")

        if query: 

            rateshows = Show.query.order_by(Show.rating.desc()).all()
            print(f"Search results: {rateshows}")
        else:
            rateshows = []

        return render_template('searchratingshow.html')

    return render_template('searchratingshow.html')

    

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        app.run(debug=True)
